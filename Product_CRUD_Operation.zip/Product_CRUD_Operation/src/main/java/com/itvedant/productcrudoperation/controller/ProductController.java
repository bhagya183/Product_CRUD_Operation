package com.itvedant.productcrudoperation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itvedant.productcrudoperation.dao.AddProductDAO;
import com.itvedant.productcrudoperation.dao.UpdateProductDAO;
import com.itvedant.productcrudoperation.service.ProductService;

@Controller
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("")
	public ResponseEntity<?> create(@RequestBody AddProductDAO addProductDAO){
		return ResponseEntity.ok(this.productService.create(addProductDAO));
	}
	
	@GetMapping("")
	public ResponseEntity<?> readAll(){
		return ResponseEntity.ok(this.productService.readAllProduct());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> readByProductId(@PathVariable Integer id){
		return ResponseEntity.ok(this.productService.readByProductId(id));
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> deelete(@PathVariable Integer id){
		return ResponseEntity.ok(this.productService.deleteProduct(id));
	}
	
	@PutMapping("{id}")
	public ResponseEntity<?> update(@PathVariable Integer id, @RequestBody UpdateProductDAO updateProductDAO){
		return ResponseEntity.ok(this.productService.updateProduct(id, updateProductDAO));
	}
	 
	
}
