package com.itvedant.productcrudoperation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itvedant.productcrudoperation.dao.AddProductDAO;
import com.itvedant.productcrudoperation.dao.UpdateProductDAO;
import com.itvedant.productcrudoperation.entity.Product;
import com.itvedant.productcrudoperation.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	ProductRepository productRepository;
	
	// For Creating Products
	public Product create(AddProductDAO addProductDAO) {
		
		Product product = new Product();
		
		product.setName(addProductDAO.getName());
		product.setDescription(addProductDAO.getDescription());
		product.setPrice(addProductDAO.getPrice());
		product.setQuantity(addProductDAO.getQuantity());
		
		this.productRepository.save(product);
		
		return product;
	}
	
	// For Getting All Products
	public List<Product> readAllProduct(){
		
		List<Product> product = new ArrayList<Product>();
		
		product = this.productRepository.findAll();
		
		return product;
	}
	
	// For Getting Product By using ID
	public Product readByProductId(Integer id) {
		
		Product product = new Product();
		
		product = this.productRepository.findById(id).orElse(null);
		
		return product;
	}
	
	//For Deleting product
	public String deleteProduct(Integer id) {
		
		Product product = new Product();
		
		product = this.readByProductId(id);
				
		this.productRepository.delete(product);
		
		return "Product Data Deleted";
	}
	
	//For Update Product
	public Product updateProduct(Integer id, UpdateProductDAO updateProductDAO) {
		
		Product product = new Product();
		
		product = this.readByProductId(id);
		
		if(updateProductDAO.getName() != null) {
			product.setName(updateProductDAO.getName());
		}
		if(updateProductDAO.getDescription() != null) {
			product.setDescription(updateProductDAO.getDescription());
		}
		if(updateProductDAO.getPrice() != null) {
			product.setPrice(updateProductDAO.getPrice());
		}
		if(updateProductDAO.getQuantity() != null) {
			product.setQuantity(updateProductDAO.getQuantity());
		}
		
		this.productRepository.save(product);
		
		return product;
	}
	
}
